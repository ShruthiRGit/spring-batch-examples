package com.reserve.bean;

// TODO: Auto-generated Javadoc
/**
 * The Class ResponseRegister.
 *
 * @author srajalak
 */
public class ResponseRegister {

	/** The guest id. */
	private int guestId;
	
	/** The Error message. */
	private String ErrorMessage;

	/**
	 * Instantiates a new response register.
	 */
	public ResponseRegister() {
		super();
	}

	/**
	 * Instantiates a new response register.
	 *
	 * @param guestId the guest id
	 * @param errorMessage the error message
	 */
	public ResponseRegister(int guestId, String errorMessage) {
		super();
		this.guestId = guestId;
		ErrorMessage = errorMessage;
	}

	/**
	 * Gets the guest id.
	 *
	 * @return the guest id
	 */
	public int getGuestId() {
		return guestId;
	}

	/**
	 * Sets the guest id.
	 *
	 * @param guestId the new guest id
	 */
	public void setGuestId(int guestId) {
		this.guestId = guestId;
	}

	/**
	 * Gets the error message.
	 *
	 * @return the error message
	 */
	public String getErrorMessage() {
		return ErrorMessage;
	}

	/**
	 * Sets the error message.
	 *
	 * @param errorMessage the new error message
	 */
	public void setErrorMessage(String errorMessage) {
		ErrorMessage = errorMessage;
	}

}
