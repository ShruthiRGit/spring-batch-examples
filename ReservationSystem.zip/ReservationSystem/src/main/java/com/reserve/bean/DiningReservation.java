package com.reserve.bean;

import java.util.Date;

// TODO: Auto-generated Javadoc
/**
 * The Class DiningReservation.
 *
 * @author srajalak
 */
public class DiningReservation {
	
	/** The dining reservation num. */
	private int diningReservationNum;
	
	/** The guest id. */
	private int guestId;
	
	/** The dining type. */
	private String diningType;
	
	/** The arrival date. */
	private Date arrivalDate;
	
	/** The no of people. */
	private int noOfPeople;
	
	/** The status. */
	private String status;
	
	/** The created date. */
	private Date createdDate;
	
	/** The updated date. */
	private Date updatedDate;
	
	/**
	 * Gets the dining reservation num.
	 *
	 * @return the dining reservation num
	 */
	public int getDiningReservationNum() {
		return diningReservationNum;
	}
	
	/**
	 * Sets the dining reservation num.
	 *
	 * @param diningReservationNum the new dining reservation num
	 */
	public void setDiningReservationNum(int diningReservationNum) {
		this.diningReservationNum = diningReservationNum;
	}
	
	/**
	 * Gets the guest id.
	 *
	 * @return the guest id
	 */
	public int getGuestId() {
		return guestId;
	}
	
	/**
	 * Sets the guest id.
	 *
	 * @param guestId the new guest id
	 */
	public void setGuestId(int guestId) {
		this.guestId = guestId;
	}
	
	/**
	 * Gets the dining type.
	 *
	 * @return the dining type
	 */
	public String getDiningType() {
		return diningType;
	}
	
	/**
	 * Sets the dining type.
	 *
	 * @param diningType the new dining type
	 */
	public void setDiningType(String diningType) {
		this.diningType = diningType;
	}
	
	/**
	 * Gets the arrival date.
	 *
	 * @return the arrival date
	 */
	public Date getArrivalDate() {
		return arrivalDate;
	}
	
	/**
	 * Sets the arrival date.
	 *
	 * @param arrivalDate the new arrival date
	 */
	public void setArrivalDate(Date arrivalDate) {
		this.arrivalDate = arrivalDate;
	}
	
	/**
	 * Gets the no of people.
	 *
	 * @return the no of people
	 */
	public int getNoOfPeople() {
		return noOfPeople;
	}
	
	/**
	 * Sets the no of people.
	 *
	 * @param noOfPeople the new no of people
	 */
	public void setNoOfPeople(int noOfPeople) {
		this.noOfPeople = noOfPeople;
	}
	
	/**
	 * Gets the status.
	 *
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}
	
	/**
	 * Sets the status.
	 *
	 * @param status the new status
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	
	/**
	 * Gets the created date.
	 *
	 * @return the created date
	 */
	public Date getCreatedDate() {
		return createdDate;
	}
	
	/**
	 * Sets the created date.
	 *
	 * @param createdDate the new created date
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	
	/**
	 * Gets the updated date.
	 *
	 * @return the updated date
	 */
	public Date getUpdatedDate() {
		return updatedDate;
	}
	
	/**
	 * Sets the updated date.
	 *
	 * @param updatedDate the new updated date
	 */
	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "DiningReservation [diningReservationNum=" + diningReservationNum + ", guestId=" + guestId
				+ ", diningType=" + diningType + ", arrivalDate=" + arrivalDate + ", noOfPeople=" + noOfPeople
				+ ", status=" + status + ", createdDate=" + createdDate + ", updatedDate=" + updatedDate + "]";
	}


}
