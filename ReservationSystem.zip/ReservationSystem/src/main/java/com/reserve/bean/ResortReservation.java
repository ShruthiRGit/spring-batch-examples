package com.reserve.bean;

import java.util.Date;

// TODO: Auto-generated Javadoc
/**
 * The Class ResortReservation.
 *
 * @author srajalak
 */
public class ResortReservation {
	
	/** The reservation number. */
	private int reservationNumber;
	
	/** The guest id. */
	private int guestId;
	
	/** The room type. */
	private String roomType;
	
	/** The arrival date. */
	private Date arrivalDate;
	
	/** The departure date. */
	private Date departureDate;
	
	/** The no of people. */
	private int noOfPeople;
	
	/** The status. */
	private String status;
	
	/** The created date. */
	private Date createdDate;
	
	/** The updated date. */
	private Date updatedDate;
	
	/**
	 * Gets the reservation number.
	 *
	 * @return the reservation number
	 */
	public int getReservationNumber() {
		return reservationNumber;
	}
	
	/**
	 * Sets the reservation number.
	 *
	 * @param reservationNumber the new reservation number
	 */
	public void setReservationNumber(int reservationNumber) {
		this.reservationNumber = reservationNumber;
	}
	
	/**
	 * Gets the guest id.
	 *
	 * @return the guest id
	 */
	public int getGuestId() {
		return guestId;
	}
	
	/**
	 * Sets the guest id.
	 *
	 * @param guestId the new guest id
	 */
	public void setGuestId(int guestId) {
		this.guestId = guestId;
	}
	
	/**
	 * Gets the room type.
	 *
	 * @return the room type
	 */
	public String getRoomType() {
		return roomType;
	}
	
	/**
	 * Sets the room type.
	 *
	 * @param roomType the new room type
	 */
	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}
	
	/**
	 * Gets the arrival date.
	 *
	 * @return the arrival date
	 */
	public Date getArrivalDate() {
		return arrivalDate;
	}
	
	/**
	 * Sets the arrival date.
	 *
	 * @param arrivalDate the new arrival date
	 */
	public void setArrivalDate(Date arrivalDate) {
		this.arrivalDate = arrivalDate;
	}
	
	/**
	 * Gets the departure date.
	 *
	 * @return the departure date
	 */
	public Date getDepartureDate() {
		return departureDate;
	}
	
	/**
	 * Sets the departure date.
	 *
	 * @param departureDate the new departure date
	 */
	public void setDepartureDate(Date departureDate) {
		this.departureDate = departureDate;
	}
	
	/**
	 * Gets the no of people.
	 *
	 * @return the no of people
	 */
	public int getNoOfPeople() {
		return noOfPeople;
	}
	
	/**
	 * Sets the no of people.
	 *
	 * @param noOfPeople the new no of people
	 */
	public void setNoOfPeople(int noOfPeople) {
		this.noOfPeople = noOfPeople;
	}
	
	/**
	 * Gets the status.
	 *
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}
	
	/**
	 * Sets the status.
	 *
	 * @param status the new status
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	
	/**
	 * Gets the created date.
	 *
	 * @return the created date
	 */
	public Date getCreatedDate() {
		return createdDate;
	}
	
	/**
	 * Sets the created date.
	 *
	 * @param createdDate the new created date
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	
	/**
	 * Gets the updated date.
	 *
	 * @return the updated date
	 */
	public Date getUpdatedDate() {
		return updatedDate;
	}
	
	/**
	 * Sets the updated date.
	 *
	 * @param updatedDate the new updated date
	 */
	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "ResortReservation [reservationNumber=" + reservationNumber + ", guestId=" + guestId + ", roomType="
				+ roomType + ", arrivalDate=" + arrivalDate + ", departureDate=" + departureDate + ", noOfPeople="
				+ noOfPeople + ", status=" + status + ", createdDate=" + createdDate + ", updatedDate=" + updatedDate
				+ "]";
	}



}
