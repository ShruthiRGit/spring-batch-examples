package com.reserve.service;

import com.reserve.bean.Guest;
import com.reserve.util.GuestException;

// TODO: Auto-generated Javadoc
/**
 * The Interface LoginService.
 *
 * @author srajalak
 */
public interface LoginService {

	/**
	 * Adds the guest.
	 *
	 * @param guest the guest
	 * @return the int
	 * @throws Exception the exception
	 */
	public int addGuest(Guest guest) throws Exception;

	/**
	 * Validate guest.
	 *
	 * @param emailId the email id
	 * @param password the password
	 * @return true, if successful
	 * @throws GuestException the guest exception
	 */
	public boolean validateGuest(String emailId, String password) throws GuestException;
}
