package com.reserve.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.reserve.bean.Guest;
import com.reserve.bean.ResponseRegister;
import com.reserve.service.LoginService;
import com.reserve.util.GuestException;

/**
 * The Class LoginController.
 *
 * @author srajalak
 */
@RestController
@RequestMapping("/guest-login")
public class LoginController {

	/** The login service. */
	@Autowired
	private LoginService loginService;

	/**
	 * Adds the guest details.
	 *
	 * @param guest the guest
	 * @return the response entity
	 * @throws Exception the exception
	 */
	@RequestMapping(value = "/add-guest", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<ResponseRegister> addGuestDetails(@RequestBody Guest guest) throws Exception {
		int guestId = 0;
		HttpHeaders headers = new HttpHeaders();
		ResponseRegister register = new ResponseRegister();

		if (guest == null) {
			return new ResponseEntity<ResponseRegister>(HttpStatus.BAD_REQUEST);
		}
		guestId = loginService.addGuest(guest);

		if (guestId == 0) {
			register.setErrorMessage("Given Email Id is already present");
			return new ResponseEntity<ResponseRegister>(register, HttpStatus.BAD_REQUEST);
		}
		register.setGuestId(guestId);
		register.setErrorMessage("null");
		headers.add("Guest Created  - ", String.valueOf(guest.getGuestId()));
		return new ResponseEntity<ResponseRegister>(register, HttpStatus.CREATED);
	}

	/**
	 * Validate.
	 *
	 * @param guest the guest
	 * @return the response entity
	 * @throws GuestException the guest exception
	 */
	@PostMapping("/validate")
	public ResponseEntity<String> validate(@RequestBody Guest guest) throws GuestException {
		String result = "guest invalid";
		boolean v = loginService.validateGuest(guest.getEmail(), guest.getPassword());
		if (v != false) {
			result = "guest valid";
			return new ResponseEntity<String>(result, HttpStatus.FOUND);
		}
		return new ResponseEntity<String>(result, HttpStatus.NOT_FOUND);
	}

}
