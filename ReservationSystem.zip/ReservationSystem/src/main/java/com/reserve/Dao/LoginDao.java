package com.reserve.Dao;

import com.reserve.bean.Guest;
import com.reserve.util.GuestException;

// TODO: Auto-generated Javadoc
/**
 * The Interface LoginDao.
 *
 * @author srajalak
 */
public interface LoginDao {

	/**
	 * Adds the guest.
	 *
	 * @param guest
	 *            the guest
	 * @return the int
	 * @throws GuestException
	 *             the guest exception
	 */
	public int addGuest(Guest guest) throws GuestException;

	/**
	 * Validate guest.
	 *
	 * @param emailId
	 *            the email id
	 * @param password
	 *            the password
	 * @return true, if successful
	 * @throws GuestException
	 *             the guest exception
	 */
	public boolean validateGuest(String emailId, String password) throws GuestException;

}
