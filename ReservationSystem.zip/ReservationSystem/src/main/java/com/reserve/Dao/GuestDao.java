package com.reserve.Dao;

import com.reserve.bean.DiningReservation;
import com.reserve.bean.ResortReservation;
import com.reserve.util.GuestException;

/**
 * The Interface GuestDao.
 */
public interface GuestDao {

	/**
	 * Gets the booking details.
	 *
	 * @param guestId the guest id
	 * @return the booking details
	 * @throws GuestException the guest exception
	 */
	public DiningReservation getBookingDetails(int guestId) throws GuestException;

	/**
	 * Gets the resort details.
	 *
	 * @param guestId the guest id
	 * @return the resort details
	 * @throws GuestException the guest exception
	 */
	public ResortReservation getResortDetails(int guestId) throws GuestException;

	/**
	 * Cancel dining.
	 *
	 * @param diningReservationNum the dining reservation num
	 * @return the dining reservation
	 * @throws GuestException the guest exception
	 */
	public DiningReservation cancelDining(int diningReservationNum) throws GuestException;

	/**
	 * Cancel resort.
	 *
	 * @param resortReservationNum the resort reservation num
	 * @return the resort reservation
	 * @throws GuestException the guest exception
	 */
	public ResortReservation cancelResort(int resortReservationNum) throws GuestException;

	/**
	 * Book resort.
	 *
	 * @param resortReservation the resort reservation
	 * @param guestId the guest id
	 * @return the int
	 * @throws GuestException the guest exception
	 */
	public int bookResort(ResortReservation resortReservation, int guestId) throws GuestException;

	/**
	 * Book dining.
	 *
	 * @param diningReservation the dining reservation
	 * @param guestId the guest id
	 * @return the int
	 * @throws GuestException the guest exception
	 */
	public int bookDining(DiningReservation diningReservation, int guestId) throws GuestException;
}
